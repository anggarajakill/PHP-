<?php
$nilai=65;

if($nilai >=91){
    echo" A ";
} else if ($nilai >= 75){
    echo" B ";
} else if ($nilai >= 65){
    echo" C ";
}


 
?>